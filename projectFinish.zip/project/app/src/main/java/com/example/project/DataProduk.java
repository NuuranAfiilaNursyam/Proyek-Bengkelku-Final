package com.example.project;

public class DataProduk {
    static String[] nameArray = {"Helm", "Pedal Motor", "Jok Motor", "Oli Motor", "Spion Motor", "Injeksi Motor", "Rem Motor","Cakram Motor", "Aki Motor", "Helm Ksatria", "Remot Control Motor"};
    static String[] versionArray = {"100.999", "104.000", "230.000", "40.000", "100.000", "200.000", "100.000", "500.000", "300.000", "200.000","500.000"};

    static Integer[] drawableArray = {R.drawable.group6, R.drawable.group9, R.drawable.group8,
            R.drawable.group1, R.drawable.group5, R.drawable.group7, R.drawable.group2,
            R.drawable.group4, R.drawable.group10, R.drawable.group6,R.drawable.group3};

    static Integer[] id_ = {0, 1, 2, 3, 4, 5, 6, 7, 8, 9, 10};
}
